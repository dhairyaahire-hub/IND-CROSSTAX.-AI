import React, { useState, useEffect, useRef } from 'react';
import { 
  Play, 
  Pause, 
  RotateCcw, 
  Volume2, 
  VolumeX, 
  Share2, 
  Copy, 
  Check, 
  ArrowRight, 
  Video, 
  Download, 
  FileCode, 
  Smartphone, 
  ExternalLink, 
  Info,
  Youtube,
  Languages,
  Sparkles,
  Subtitles,
  X,
  FileText
} from 'lucide-react';
import { AnimatedIndianFlagLogo } from './AnimatedIndianFlagLogo';

interface StandaloneVideoPortalProps {
  onExitToApp?: () => void;
}

interface Scene {
  id: number;
  tag: string;
  title: string;
  voice: string;
  subtitles: string;
  badgeColor: string;
  bullets: string[];
}

export const StandaloneVideoPortal: React.FC<StandaloneVideoPortalProps> = ({ onExitToApp }) => {
  const [language, setLanguage] = useState<'hi' | 'en'>('hi');
  const [currentSceneIdx, setCurrentSceneIdx] = useState<number>(0);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [voiceEnabled, setVoiceEnabled] = useState<boolean>(true);
  const [progress, setProgress] = useState<number>(0);
  const [copied, setCopied] = useState<boolean>(false);
  const [downloadSuccess, setDownloadSuccess] = useState<boolean>(false);
  const [isYouTubeKitOpen, setIsYouTubeKitOpen] = useState<boolean>(false);
  const [copiedKitSection, setCopiedKitSection] = useState<string | null>(null);

  const timerRef = useRef<any>(null);

  // Scenes in English
  const scenesEn: Scene[] = [
    {
      id: 1,
      tag: "THE PROBLEM: 20% TAX LEAKAGE",
      title: "The Multi-Million Dollar Cross-Border Tax Leakage",
      voice: "Are your cross-border IT clients, SaaS exporters, or multinational companies losing 15 to 20 percent on overseas invoices to foreign withholding taxes? Every year, billions of dollars are trapped in unnecessary double taxation and aggressive transfer pricing audits.",
      subtitles: "15%–20% of cross-border IT revenue is lost to overseas withholding taxes and Chapter X transfer pricing disputes.",
      badgeColor: "bg-red-500/20 text-red-400 border-red-500/30",
      bullets: [
        "20% to 30% standard withholding deducted on US, UK, and Singapore invoices",
        "Complex Indian Chapter X & OECD Transfer Pricing documentation requirements",
        "Costly non-compliance penalties & delayed Form 10F filings"
      ]
    },
    {
      id: 2,
      tag: "THE SOLUTION: AUTOMATED RELIEF",
      title: "Meet IND CROSSTAX AI: The Solution",
      voice: "Welcome to IND CROSSTAX AI — the next-generation tax automation platform built specifically for Chartered Accountants, corporate finance teams, IT exporters, and enterprise tax desks. We turn weeks of complex legal treaty research into an instant 3-minute audit-ready dossier.",
      subtitles: "IND CROSSTAX AI: Real-time DTAA Double Tax Relief & OECD Transfer Pricing Benchmarking.",
      badgeColor: "bg-emerald-500/20 text-emerald-400 border-emerald-500/30",
      bullets: [
        "Covers 85+ Bilateral Treaties (US, UK, Singapore, UAE, Germany, Japan)",
        "Compliant with Indian Section 92C Chapter X & OECD 2022 Guidelines",
        "Automatic Withholding Tax Optimization from 20% down to 0%–10%"
      ]
    },
    {
      id: 3,
      tag: "LIVE TUTORIAL: 3 SIMPLE STEPS",
      title: "Live Walkthrough: How the Platform Works",
      voice: "Using the platform takes just three simple steps. First, enter your contract details. Second, our engine analyzes exact bilateral DTAA treaty articles, assessing Permanent Establishment risk, FTS classification, and arm's length markups. Third, download a fully audit-ready Form 10F and No-PE Certificate in Microsoft Word with a single click.",
      subtitles: "Step 1: Intake → Step 2: DTAA & TP Safe Harbour Benchmark → Step 3: 1-Click Form 10F Word Dossier.",
      badgeColor: "bg-indigo-500/20 text-indigo-300 border-indigo-500/30",
      bullets: [
        "Step 1: Guided Contract Intake (Software, Royalty, Management Fees, Loans)",
        "Step 2: Instant Arm's Length Range (TNMM, CUP, Safe Harbour Rule 10TD)",
        "Step 3: One-Click Statutory Legal Drafts (.DOCX ready for e-filing)"
      ]
    },
    {
      id: 4,
      tag: "REVENUE OPPORTUNITY FOR CA FIRMS",
      title: "Scope of Work & High Margin for CA Offices",
      voice: "For CA firms and tax agencies, IND CROSSTAX AI is your ultimate revenue multiplier. Deliver high-margin cross-border tax advisory in minutes instead of weeks. Prepare Form 3CEB documentation and foreign vendor tax evaluations effortlessly, allowing your firm to charge 25,000 to 1,00,000 rupees per engagement.",
      subtitles: "Turn 3-week audits into 3-minute deliverables. Charge ₹25k–₹1L per client engagement.",
      badgeColor: "bg-amber-500/20 text-amber-300 border-amber-500/30",
      bullets: [
        "Expand firm services into international tax without hiring costly specialists",
        "Deliver certified Form 10F & No-PE packs to foreign enterprise clients",
        "Zero manual calculation errors with OECD & CBDT rule compliance"
      ]
    },
    {
      id: 5,
      tag: "CALL TO ACTION: GET STARTED",
      title: "Transform Your Cross-Border Tax Practice",
      voice: "Stop losing money to double taxation. Empower your clients and scale your accounting practice today with IND CROSSTAX AI. Try it now for free or get in touch with our team for agency onboarding.",
      subtitles: "Start free today. Protect your overseas revenues with IND CROSSTAX AI.",
      badgeColor: "bg-red-500/20 text-red-400 border-red-500/30",
      bullets: [
        "100% Free Live Access — No credit card or installation required",
        "Instant Microsoft Word statutory report generation",
        "Trusted by CA practitioners, IT exporters, and CFO desks worldwide"
      ]
    }
  ];

  // Professional Hindi Narration for YouTube Broadcast
  const scenesHi: Scene[] = [
    {
      id: 1,
      tag: "समस्या: 20% टैक्स का नुकसान",
      title: "विदेशी इनवॉइस पर 20% टैक्स का नुकसान — समस्या क्या है?",
      voice: "नमस्ते दोस्तों! क्या आपके भारतीय IT क्लाइंट्स, SaaS एक्सपोर्टर्स और फ्रीलांसर्स विदेशी इनवॉइस पर 15 से 20 प्रतिशत टैक्स टीडीएस में गंवा रहे हैं? हर साल करोड़ों रुपये गैर-जरूरी डबल टैक्सेशन और ट्रांसफर प्राइसिंग के विवादों में अटक जाते हैं। समय आ गया है इस टैक्स लीकेज को रोकने का!",
      subtitles: "भारतीय IT कंपनियों का 20% रेवेन्यू विदेशी Withholding Tax और ट्रांसफर प्राइसिंग में अटक जाता है।",
      badgeColor: "bg-red-500/20 text-red-400 border-red-500/30",
      bullets: [
        "US, UK और सिंगापुर इनवॉइस पर 20% से 30% तक गैर-जरूरी Withholding Tax कटना",
        "भारतीय इनकम टैक्स एक्ट Chapter X और OECD ट्रांसफर प्राइसिंग के जटिल नियम",
        "Form 10F और TRC न होने पर भारी पेनाल्टी और बैंक पेमेंट्स में देरी"
      ]
    },
    {
      id: 2,
      tag: "समाधान: IND CROSSTAX AI",
      title: "मिलिए IND CROSSTAX AI से: आपका ऑटोमेटेड DTAA टैक्स एडवाइजर",
      voice: "पेश है IND CROSSTAX AI — भारतीय चार्टर्ड अकाउंटेंट्स, कॉर्पोरेट फाइनेंस टीम्स और IT एक्सपोर्टर्स के लिए बनाया गया नेक्स्ट-जेनरेशन टैक्स ऑटोमेशन प्लेटफॉर्म। जो टैक्स रिसर्च हफ्तों का समय लेती थी, अब वो सिर्फ 3 मिनट में पूरी ऑडिट-रेडी फाइल के साथ तैयार हो जाती है!",
      subtitles: "IND CROSSTAX AI: रियल-टाइम DTAA टैक्स छूट और OECD ट्रांसफर प्राइसिंग बेंचमार्किंग।",
      badgeColor: "bg-emerald-500/20 text-emerald-400 border-emerald-500/30",
      bullets: [
        "85+ देशों के साथ भारत की DTAA ट्रीटीज (US, UK, सिंगापुर, UAE, जर्मनी, जापान)",
        "Section 92C और CBDT Rule 10TD सेफ हार्बर रूल्स के अनुसार गणना",
        "Withholding Tax 20% से घटकर सीधा 0% से 10% तक कम करने का कानूनी समाधान"
      ]
    },
    {
      id: 3,
      tag: "लाइव ट्यूटोरियल: 3 आसान स्टेप्स",
      title: "लाइव ट्यूटोरियल: सिर्फ 3 आसान स्टेप्स में टैक्स एनालिसिस",
      voice: "इस प्लेटफॉर्म को इस्तेमाल करना बहुत आसान है। स्टेप 1: अपने कॉन्ट्रैक्ट और देश की डिटेल्स दर्ज करें। स्टेप 2: हमारा AI इंजन DTAA आर्टिकल्स, परमानेंट एस्टेब्लिशमेंट रिस्क, FTS फीस और आर्म्स लेंथ मार्जिन की सटीक जांच करता है। और स्टेप 3: सिंगल क्लिक में सरकारी Form 10F और No-PE सर्टिफिकेट वर्ड फॉर्मेट में डाउनलोड करें।",
      subtitles: "स्टेप 1: कॉन्ट्रैक्ट एंट्री → स्टेप 2: DTAA व सेफ हार्बर मार्जिन टेस्ट → स्टेप 3: 1-क्लिक Form 10F रिपोर्ट।",
      badgeColor: "bg-indigo-500/20 text-indigo-300 border-indigo-500/30",
      bullets: [
        "स्टेप 1: आसान कॉन्ट्रैक्ट इनटेक (सॉफ्टवेयर IT, रॉयल्टी, कंसल्टेंसी, लोन)",
        "स्टेप 2: आर्म्स लेंथ प्राइसिंग व CBDT Rule 10TD 17% सेफ हार्बर ऑटो-चेक",
        "स्टेप 3: Microsoft Word में डाउनलोड के लिए तैयार Form 10F व No-PE सर्टिफिकेट"
      ]
    },
    {
      id: 4,
      tag: "सीए फर्म्स के लिए अवसर",
      title: "सीए फर्म्स के लिए नई कमाई का मौका और रियल-टाइम फॉरेक्स",
      voice: "सीए फर्म्स और टैक्स कंसल्टेंट्स के लिए यह कमाई का बेहतरीन जरिया है। बिना किसी इंटरनेशनल टैक्स एक्सपर्ट को हायर किए, अपने क्लाइंट्स को प्रीमियम क्रॉस-बॉर्डर एडवाइजरी दें और हर असाइनमेंट पर 25 हजार से 1 लाख रुपये तक की प्रोफेशनल फीस अर्जित करें। साथ ही रियल-टाइम RBI और इंटरबैंक करेंसी रेट्स पर तुरंत कैलकुलेशन पाएं।",
      subtitles: "सीए फर्म्स हर क्लाइंट से ₹25,000 से ₹1,00,000 तक की फीस चार्ज कर सकते हैं।",
      badgeColor: "bg-amber-500/20 text-amber-300 border-amber-500/30",
      bullets: [
        "फर्म की सर्विसेज का इंटरनेशनल एक्सपेंशन — शून्य मैन्युअल गलतियों के साथ",
        "विदेशी क्लाइंट्स के लिए प्रमाणित Form 10F और Form 3CEB सपोर्ट फाइल्स",
        "रियल-टाइम डॉलर-रुपया एक्सचेंज रेट्स और CBDT Rule 115 कंप्लायंस"
      ]
    },
    {
      id: 5,
      tag: "कॉल टू एक्शन: अभी शुरू करें",
      title: "आज ही शुरू करें — अपना क्रॉस-बॉर्डर टैक्स बचाएं",
      voice: "डबल टैक्सेशन में अपने पैसे गंवाना बंद करें। आज ही IND CROSSTAX AI का उपयोग करें। लिंक नीचे डिस्क्रिप्शन बॉक्स में दिया गया है — ind-crosstax-ai.vercel.app। वीडियो पसंद आई हो तो लाइक करें, चैनल को सब्सक्राइब करें और अपने सभी सीए व फाउंडर दोस्तों के साथ शेयर करें। धन्यवाद!",
      subtitles: "आज ही फ्री में शुरू करें: ind-crosstax-ai.vercel.app। लाइक और सब्सक्राइब जरूर करें!",
      badgeColor: "bg-red-500/20 text-red-400 border-red-500/30",
      bullets: [
        "100% फ्री लाइव एक्सेस — बिना किसी क्रेडिट कार्ड के तुरंत शुरू करें",
        "डिस्क्रिप्शन में दिए लिंक पर क्लिक करें: ind-crosstax-ai.vercel.app",
        "लाइक, शेयर और सब्सक्राइब करें नई टैक्स व फिनटेक अपडेट्स के लिए!"
      ]
    }
  ];

  const scenes = language === 'hi' ? scenesHi : scenesEn;
  const currentScene = scenes[currentSceneIdx];

  // Speech voiceover with Hindi/English language detection
  const speakScene = (text: string, lang: 'hi' | 'en' = language) => {
    if (!voiceEnabled) return;
    try {
      if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
        window.speechSynthesis.cancel();
        const utterance = new SpeechSynthesisUtterance(text);
        
        if (lang === 'hi') {
          utterance.lang = 'hi-IN';
          utterance.rate = 0.98; // Relaxed cadence for clear Hindi pronunciation
        } else {
          utterance.lang = 'en-US';
          utterance.rate = 1.02;
        }

        utterance.onerror = () => {
          // Graceful fallback
        };

        const voices = window.speechSynthesis.getVoices();
        if (voices && voices.length > 0) {
          if (lang === 'hi') {
            const hindiVoice = voices.find(v => 
              v.lang.startsWith('hi') || 
              v.lang.includes('IN') || 
              v.name.includes('Hindi') || 
              v.name.includes('India')
            );
            if (hindiVoice) utterance.voice = hindiVoice;
          } else {
            const naturalVoice = voices.find(v => 
              v.lang.startsWith('en') && 
              (v.name.includes('Natural') || v.name.includes('Google') || v.name.includes('India'))
            );
            if (naturalVoice) utterance.voice = naturalVoice;
          }
        }
        window.speechSynthesis.speak(utterance);
      }
    } catch {
      // Audio fallback
    }
  };

  const handlePlay = () => {
    setIsPlaying(true);
    speakScene(currentScene.voice, language);

    const intervalMs = 100;
    const durationSeconds = 14;
    const step = 100 / ((durationSeconds * 1000) / intervalMs);

    if (timerRef.current) clearInterval(timerRef.current);
    timerRef.current = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          setCurrentSceneIdx((curr) => {
            if (curr < scenes.length - 1) {
              const next = curr + 1;
              speakScene(scenes[next].voice, language);
              return next;
            } else {
              handlePause();
              return 0;
            }
          });
          return 0;
        }
        return prev + step;
      });
    }, intervalMs);
  };

  const handlePause = () => {
    setIsPlaying(false);
    if (timerRef.current) clearInterval(timerRef.current);
    try {
      if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
    } catch {}
  };

  const goToScene = (idx: number) => {
    setCurrentSceneIdx(idx);
    setProgress(0);
    if (isPlaying) {
      speakScene(scenes[idx].voice, language);
    }
  };

  const handleRestart = () => {
    goToScene(0);
    handlePlay();
  };

  const handleLanguageToggle = (newLang: 'hi' | 'en') => {
    setLanguage(newLang);
    const targetScenes = newLang === 'hi' ? scenesHi : scenesEn;
    if (isPlaying) {
      speakScene(targetScenes[currentSceneIdx].voice, newLang);
    }
  };

  useEffect(() => {
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
      try {
        if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
          window.speechSynthesis.cancel();
        }
      } catch {}
    };
  }, []);

  // Universal Video Link
  const videoShareUrl = typeof window !== 'undefined' ? `${window.location.origin}/?view=video` : 'https://ind-crosstax-ai.vercel.app/?view=video';

  const copyToClipboard = (text: string = videoShareUrl) => {
    try {
      if (navigator.clipboard) {
        navigator.clipboard.writeText(text);
      } else {
        const input = document.createElement('input');
        input.value = text;
        document.body.appendChild(input);
        input.select();
        document.execCommand('copy');
        document.body.removeChild(input);
      }
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    } catch {
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    }
  };

  const copyKitText = (text: string, sectionKey: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKitSection(sectionKey);
    setTimeout(() => setCopiedKitSection(null), 2000);
  };

  // Instant HTML Video Presentation File Downloader (With Hindi & English Toggle)
  const downloadVideoFile = () => {
    try {
      const htmlContent = `<!DOCTYPE html>
<html lang="hi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>IND CROSSTAX AI - Official Client Video Demo (हिंदी & English)</title>
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; }
    body { background: #030712; color: #f3f4f6; min-height: 100vh; display: flex; flex-direction: column; align-items: center; justify-content: center; padding: 20px; }
    .card { max-width: 840px; width: 100%; background: #111827; border: 1px solid #1f2937; border-radius: 20px; overflow: hidden; box-shadow: 0 25px 50px -12px rgba(0,0,0,0.5); }
    .header { padding: 16px 24px; background: #0f172a; border-bottom: 1px solid #1e293b; display: flex; justify-content: space-between; align-items: center; }
    .brand { font-weight: 800; font-size: 16px; color: #fff; }
    .brand span { color: #f59e0b; }
    .stage { aspect-ratio: 16/9; background: linear-gradient(135deg, #030712 0%, #1e1b4b 100%); padding: 32px; display: flex; flex-direction: column; justify-content: space-between; position: relative; }
    .scene-tag { display: inline-block; background: rgba(245,158,11,0.2); color: #fcd34d; font-size: 11px; font-weight: 800; padding: 4px 10px; border-radius: 9999px; border: 1px solid rgba(245,158,11,0.3); text-transform: uppercase; }
    .scene-title { font-size: 22px; font-weight: 900; color: #fff; margin: 12px 0 8px; }
    .content-box { background: rgba(17,24,39,0.85); border: 1px solid rgba(55,65,81,0.8); border-radius: 14px; padding: 16px; font-size: 13px; line-height: 1.5; color: #d1d5db; }
    .subtitles { background: rgba(0,0,0,0.8); border: 1px solid rgba(255,255,255,0.1); border-radius: 10px; padding: 10px 14px; text-align: center; color: #fef08a; font-size: 13px; font-style: italic; }
    .controls { padding: 16px 24px; background: #0f172a; border-top: 1px solid #1e293b; display: flex; justify-content: space-between; align-items: center; flex-wrap: gap: 10px; }
    .btn { background: #dc2626; color: #fff; border: none; padding: 8px 16px; border-radius: 8px; font-weight: 700; cursor: pointer; font-size: 13px; }
    .btn:hover { background: #b91c1c; }
    .lang-btn { background: #1f2937; color: #e5e7eb; border: 1px solid #374151; padding: 6px 12px; border-radius: 6px; font-size: 11px; font-weight: 700; cursor: pointer; margin-left: 6px; }
    .lang-btn.active { background: #f59e0b; color: #000; border-color: #f59e0b; }
    .progress-bar { width: 100%; height: 4px; background: #1f2937; }
    .progress-fill { height: 100%; background: linear-gradient(90deg, #f59e0b, #dc2626); width: 0%; transition: width 0.1s linear; }
    .nav-btn { background: #1f2937; color: #9ca3af; border: none; padding: 4px 10px; border-radius: 6px; font-size: 12px; cursor: pointer; margin-left: 4px; }
    .nav-btn.active { background: #f59e0b; color: #000; font-weight: 800; }
  </style>
</head>
<body>
  <div class="card">
    <div class="header">
      <div class="brand"><span>IND</span> CROSSTAX AI &bull; Video Demo</div>
      <div>
        <button id="langHi" class="lang-btn active" onclick="setLang('hi')">🇮🇳 हिंदी आवाज़</button>
        <button id="langEn" class="lang-btn" onclick="setLang('en')">🇬🇧 English</button>
      </div>
    </div>
    <div class="stage">
      <div>
        <span id="sceneTag" class="scene-tag">दृश्य 1 / 5</span>
        <div id="sceneTitle" class="scene-title">विदेशी इनवॉइस पर 20% टैक्स का नुकसान — समस्या क्या है?</div>
      </div>
      <div id="contentBox" class="content-box">
        • US, UK और सिंगापुर इनवॉइस पर 20% से 30% तक गैर-जरूरी Withholding Tax कटना<br>
        • भारतीय इनकम टैक्स एक्ट Chapter X और OECD ट्रांसफर प्राइसिंग के जटिल नियम<br>
        • Form 10F और TRC न होने पर भारी पेनाल्टी और बैंक पेमेंट्स में देरी
      </div>
      <div id="subtitles" class="subtitles">
        "भारतीय IT कंपनियों का 20% रेवेन्यू विदेशी Withholding Tax और ट्रांसफर प्राइसिंग में अटक जाता है।"
      </div>
    </div>
    <div class="progress-bar">
      <div id="progressFill" class="progress-fill"></div>
    </div>
    <div class="controls">
      <div>
        <button id="playBtn" class="btn">▶ वीडियो चलाएं (Play)</button>
      </div>
      <div>
        <button class="nav-btn active" onclick="jump(0)">1</button>
        <button class="nav-btn" onclick="jump(1)">2</button>
        <button class="nav-btn" onclick="jump(2)">3</button>
        <button class="nav-btn" onclick="jump(3)">4</button>
        <button class="nav-btn" onclick="jump(4)">5</button>
      </div>
    </div>
  </div>
  <script>
    const dataHi = [
      { tag: "समस्या: 20% टैक्स लीकेज", title: "विदेशी इनवॉइस पर 20% टैक्स का नुकसान — समस्या क्या है?", text: "• US, UK और सिंगापुर इनवॉइस पर 20% से 30% तक TDS कटना<br>• भारतीय Chapter X और OECD ट्रांसफर प्राइसिंग के जटिल नियम<br>• Form 10F न होने पर भारी पेनाल्टी व पेमेंट्स में रुकावट", sub: "क्या आपके भारतीय IT क्लाइंट्स विदेशी इनवॉइस पर 15 से 20 प्रतिशत टैक्स टीडीएस में गंवा रहे हैं?" },
      { tag: "समाधान: IND CROSSTAX AI", title: "मिलिए IND CROSSTAX AI से: आपका DTAA टैक्स इंजन", text: "• 85+ देशों के साथ भारत की DTAA ट्रीटीज (US, UK, सिंगापुर, UAE)<br>• Section 92C और CBDT Rule 10TD सेफ हार्बर रूल्स<br>• Withholding Tax 20% से घटाकर सीधा 0% से 10% तक कम", sub: "IND CROSSTAX AI: रियल-टाइम DTAA टैक्स छूट और OECD ट्रांसफर प्राइसिंग बेंचमार्किंग।" },
      { tag: "लाइव ट्यूटोरियल: 3 स्टेप्स", title: "लाइव ट्यूटोरियल: सिर्फ 3 आसान स्टेप्स में टैक्स एनालिसिस", text: "• स्टेप 1: कॉन्ट्रैक्ट एंट्री व देश की डिटेल्स<br>• स्टेप 2: DTAA व सेफ हार्बर मार्जिन टेस्ट (Rule 10TD)<br>• स्टेप 3: 1-क्लिक Word Form 10F व No-PE रिपोर्ट", sub: "जो टैक्स रिसर्च हफ्तों का समय लेती थी, अब वो सिर्फ 3 मिनट में पूरी ऑडिट-रेडी फाइल के साथ तैयार!" },
      { tag: "सीए फर्म्स के लिए कमाई", title: "सीए फर्म्स के लिए नई कमाई का मौका और रियल-टाइम फॉरेक्स", text: "• फर्म की सर्विसेज का इंटरनेशनल टैक्स एक्सपेंशन<br>• विदेशी क्लाइंट्स के लिए प्रमाणित Form 10F और Form 3CEB<br>• रियल-टाइम डॉलर-रुपया एक्सचेंज रेट्स (CBDT Rule 115)", sub: "सीए फर्म्स हर क्लाइंट से ₹25,000 से ₹1,00,000 तक की फीस चार्ज कर सकते हैं।" },
      { tag: "कॉल टू एक्शन: अभी शुरू करें", title: "आज ही शुरू करें — अपना क्रॉस-बॉर्डर टैक्स बचाएं", text: "• 100% फ्री लाइव एक्सेस: ind-crosstax-ai.vercel.app<br>• तत्काल Microsoft Word रिपोर्ट डाउनलोड<br>• भारत के CAs व IT एक्सपोर्टर्स द्वारा विश्वसनीय", sub: "आज ही फ्री में शुरू करें: ind-crosstax-ai.vercel.app। लाइक और सब्सक्राइब जरूर करें!" }
    ];
    const dataEn = [
      { tag: "SCENE 1: THE PROBLEM", title: "The Cross-Border Tax Leakage", text: "• 20% to 30% withholding deducted on overseas invoices.<br>• Foreign payers demand Form 10F & No-PE affidavits.<br>• Huge double tax losses for IT exporters.", sub: "15% to 20% of cross-border IT revenue is lost to foreign withholding taxes." },
      { tag: "SCENE 2: THE SOLUTION", title: "Meet IND CROSSTAX AI", text: "• 85+ Bilateral Treaties (US, UK, Singapore, UAE, Japan).<br>• Indian Chapter X & OECD 2022 Transfer Pricing Safe Harbour.<br>• Automatic tax optimization from 20% to 0%.", sub: "IND CROSSTAX AI: Real-time DTAA double tax relief & arm's length benchmarks." },
      { tag: "SCENE 3: WALKTHROUGH", title: "3-Step Live Platform Tutorial", text: "• Step 1: Input contract details & countries.<br>• Step 2: Instant DTAA & Safe Harbour Rule 10TD calculations.<br>• Step 3: One-click Word Form 10F & No-PE pack download.", sub: "Turn 3 weeks of cross-border legal research into a 3-minute Word dossier." },
      { tag: "SCENE 4: CA REVENUE", title: "High-Margin Services for CA Firms", text: "• Deliver certified Form 10F packs to international clients.<br>• File Form 3CEB transfer pricing audits with confidence.<br>• Charge ₹25,000 to ₹1,00,000 per engagement.", sub: "Expand your practice into global tax advisory and boost firm revenue." },
      { tag: "SCENE 5: CALL TO ACTION", title: "Start Protecting Your Revenue", text: "• 100% Free Live Access.<br>• Instant Microsoft Word report downloads.<br>• Trusted by CAs, IT exporters, and CFO desks.", sub: "Start free today and protect your overseas revenues from double taxation." }
    ];

    let lang = 'hi';
    let data = dataHi;
    let cur = 0, playing = false, progress = 0, interval;
    const playBtn = document.getElementById('playBtn');
    const tag = document.getElementById('sceneTag');
    const title = document.getElementById('sceneTitle');
    const box = document.getElementById('contentBox');
    const sub = document.getElementById('subtitles');
    const fill = document.getElementById('progressFill');
    const navBtns = document.querySelectorAll('.nav-btn');

    function setLang(l) {
      lang = l;
      data = lang === 'hi' ? dataHi : dataEn;
      document.getElementById('langHi').className = lang === 'hi' ? 'lang-btn active' : 'lang-btn';
      document.getElementById('langEn').className = lang === 'en' ? 'lang-btn active' : 'lang-btn';
      update(cur);
    }

    function update(idx) {
      cur = idx;
      tag.innerText = data[idx].tag;
      title.innerText = data[idx].title;
      box.innerHTML = data[idx].text;
      sub.innerText = '"' + data[idx].sub + '"';
      navBtns.forEach((b, i) => b.className = i === idx ? 'nav-btn active' : 'nav-btn');
      if ('speechSynthesis' in window && playing) {
        window.speechSynthesis.cancel();
        const u = new SpeechSynthesisUtterance(data[idx].sub);
        u.lang = lang === 'hi' ? 'hi-IN' : 'en-US';
        u.rate = lang === 'hi' ? 0.98 : 1.02;
        window.speechSynthesis.speak(u);
      }
    }
    function jump(idx) {
      progress = 0;
      fill.style.width = '0%';
      update(idx);
    }
    playBtn.onclick = function() {
      if (playing) {
        playing = false;
        playBtn.innerText = lang === 'hi' ? '▶ वीडियो चलाएं' : '▶ Play Video';
        clearInterval(interval);
        if ('speechSynthesis' in window) window.speechSynthesis.cancel();
      } else {
        playing = true;
        playBtn.innerText = lang === 'hi' ? '⏸ रोकें (Pause)' : '⏸ Pause Video';
        update(cur);
        interval = setInterval(() => {
          progress += 0.8;
          if (progress >= 100) {
            progress = 0;
            if (cur < 4) { cur++; update(cur); } else { playBtn.click(); cur = 0; }
          }
          fill.style.width = progress + '%';
        }, 100);
      }
    };
  </script>
</body>
</html>`;

      const blob = new Blob([htmlContent], { type: 'text/html' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'IND-CROSSTAX-AI-Video-Demo-Hindi.html';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);

      setDownloadSuccess(true);
      setTimeout(() => setDownloadSuccess(false), 3000);
    } catch (e) {
      console.error('Download error:', e);
    }
  };

  const whatsappMessage = encodeURIComponent(
    `नमस्ते! IND CROSSTAX AI का यह 90 सेकंड का वीडियो डेमो देखें। यह दिखाता है कि कैसे भारतीय IT एक्सपोर्टर्स और CA फर्म्स विदेशी इनवॉइस पर 20% Withholding Tax बचा सकते हैं और 3 मिनट में सरकारी Form 10F व No-PE सर्टिफिकेट डाउनलोड कर सकते हैं:\n${videoShareUrl}`
  );

  // YouTube Description text ready to paste
  const youtubeDescriptionText = `🇮🇳 विदेशी इनवॉइस पर 20% टैक्स कैसे बचाएं? DTAA Relief, Form 10F & Transfer Pricing Complete Guide in Hindi | IND CROSSTAX AI

क्या आपके विदेशी IT क्लाइंट्स US, UK या सिंगापुर के इनवॉइस पर 15% से 20% Withholding Tax (WHT/TDS) काट रहे हैं? 
इस वीडियो में जानें कि IND CROSSTAX AI की मदद से कैसे भारतीय चार्टर्ड अकाउंटेंट्स, टेक फाउंडर्स और IT एक्सपोर्टर्स सिर्फ 3 मिनट में DTAA ट्रीटी रिलीफ का लाभ उठाकर 20% टैक्स को घटाकर 0% से 10% कर सकते हैं।

🌐 Live Web Application (Free Access):
👉 https://ind-crosstax-ai.vercel.app

🎬 Direct Video Presentation Link:
👉 https://ind-crosstax-ai.vercel.app/?view=video

⏱️ Video Chapters / Timestamps:
0:00 - Introduction & The 20% Tax Leakage Problem
0:45 - What is IND CROSSTAX AI?
1:35 - Live Demo: 3 Simple Steps for Cross-Border Tax Intake
2:45 - Real-Time Interbank Currency Converter & CBDT Rule 10TD Safe Harbour
3:45 - High-Margin Revenue Opportunity for CA Firms (₹25k - ₹1L per engagement)
4:30 - How to Access for Free & 1-Click Form 10F Word Download

Key Highlights Covered:
✅ Section 92C Chapter X & OECD 2022 Transfer Pricing
✅ CBDT Rule 10TD Safe Harbour (17% profit markup for IT exporters)
✅ Form 10F Electronic Self-Declaration & TRC Section 90(4)
✅ Article 5 Permanent Establishment (PE) Risk Mitigation
✅ Real-Time Interbank Forex Engine with CBDT Rule 115 Compliance

🔔 Subscribe to our channel for the latest updates on International Taxation, Indian Income-tax Act, Transfer Pricing, and Fintech Automation.

#DTAA #TransferPricing #Form10F #CharteredAccountant #IncomeTaxIndia #ITExport #TaxSaving #Vercel #Fintech #IndianCA #CrossBorderTax`;

  const youtubeScriptFullHindi = `[SCENE 1: 0:00 - 0:45]
नमस्ते दोस्तों! क्या आपके भारतीय IT क्लाइंट्स, SaaS एक्सपोर्टर्स और फ्रीलांसर्स विदेशी इनवॉइस पर 15 से 20 प्रतिशत टैक्स टीडीएस में गंवा रहे हैं? हर साल करोड़ों रुपये गैर-जरूरी डबल टैक्सेशन और ट्रांसफर प्राइसिंग के विवादों में अटक जाते हैं। समय आ गया है इस टैक्स लीकेज को रोकने का!

[SCENE 2: 0:45 - 1:35]
पेश है IND CROSSTAX AI — भारतीय चार्टर्ड अकाउंटेंट्स, कॉर्पोरेट फाइनेंस टीम्स और IT एक्सपोर्टर्स के लिए बनाया गया नेक्स्ट-जेनरेशन टैक्स ऑटोमेशन प्लेटफॉर्म। जो टैक्स रिसर्च हफ्तों का समय लेती थी, अब वो सिर्फ 3 मिनट में पूरी ऑडिट-रेडी फाइल के साथ तैयार हो जाती है!

[SCENE 3: 1:35 - 2:45]
इस प्लेटफॉर्म को इस्तेमाल करना बहुत आसान है। स्टेप 1: अपने कॉन्ट्रैक्ट और देश की डिटेल्स दर्ज करें। स्टेप 2: हमारा AI इंजन DTAA आर्टिकल्स, परमानेंट एस्टेब्लिशमेंट रिस्क, FTS फीस और आर्म्स लेंथ मार्जिन की सटीक जांच करता है। और स्टेप 3: सिंगल क्लिक में सरकारी Form 10F और No-PE सर्टिफिकेट वर्ड फॉर्मेट में डाउनलोड करें।

[SCENE 4: 2:45 - 3:45]
सीए फर्म्स और टैक्स कंसल्टेंट्स के लिए यह कमाई का बेहतरीन जरिया है। बिना किसी इंटरनेशनल टैक्स एक्सपर्ट को हायर किए, अपने क्लाइंट्स को प्रीमियम क्रॉस-बॉर्डर एडवाइजरी दें और हर असाइनमेंट पर 25 हजार से 1 लाख रुपये तक की प्रोफेशनल फीस अर्जित करें। साथ ही रियल-टाइम RBI और इंटरबैंक करेंसी रेट्स पर तुरंत कैलकुलेशन पाएं।

[SCENE 5: 3:45 - 4:40]
डबल टैक्सेशन में अपने पैसे गंवाना बंद करें। आज ही IND CROSSTAX AI का उपयोग करें। लिंक नीचे डिस्क्रिप्शन बॉक्स में दिया गया है — ind-crosstax-ai.vercel.app। वीडियो पसंद आई हो तो लाइक करें, चैनल को सब्सक्राइब करें और अपने सभी सीए व फाउंडर दोस्तों के साथ शेयर करें। धन्यवाद!`;

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans antialiased selection:bg-red-500 selection:text-white">
      {/* Top Header */}
      <header className="border-b border-slate-800 bg-slate-900/90 backdrop-blur-md sticky top-0 z-50">
        <div className="max-w-6xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <AnimatedIndianFlagLogo size="md" />
            <div>
              <span className="font-extrabold text-white text-base tracking-tight">
                <span className="text-amber-500">IND</span> CROSSTAX <span className="text-red-500">AI</span>
              </span>
              <span className="text-[10px] text-slate-400 block font-mono">B2B TAX AUTOMATION &bull; VIDEO DEMO</span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* YouTube Creator Kit Trigger */}
            <button
              type="button"
              onClick={() => setIsYouTubeKitOpen(true)}
              className="text-xs font-bold text-white bg-red-600 hover:bg-red-700 px-3 py-1.5 rounded-xl transition flex items-center gap-1.5 shadow-md cursor-pointer"
            >
              <Youtube className="w-4 h-4 text-white" />
              <span className="hidden sm:inline">YouTube Publish Kit</span>
            </button>

            {/* Launch App */}
            <button
              type="button"
              onClick={onExitToApp || (() => { window.location.href = '/'; })}
              className="text-xs font-bold text-slate-200 hover:text-white px-3.5 py-1.5 rounded-xl border border-slate-700 bg-slate-800 hover:bg-slate-700 transition flex items-center gap-1.5 cursor-pointer"
            >
              <span>Launch Live Calculator</span>
              <ArrowRight className="w-3.5 h-3.5 text-amber-400" />
            </button>
          </div>
        </div>
      </header>

      {/* Main Body */}
      <main className="flex-1 max-w-5xl mx-auto w-full px-4 py-8 space-y-6">
        {/* Pitch Headline & Narration Language Switcher */}
        <div className="text-center space-y-3 max-w-3xl mx-auto">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-black bg-amber-500/20 text-amber-300 border border-amber-500/30 uppercase tracking-wider">
            <Video className="w-3.5 h-3.5 text-amber-400" />
            <span>Official Video Presentation &bull; YouTube Recording Studio</span>
          </div>

          <h1 className="text-2xl sm:text-4xl font-extrabold tracking-tight text-white leading-tight">
            {language === 'hi' 
              ? 'विदेशी इनवॉइस पर 20% टैक्स बचाएं — DTAA व Form 10F डेमो' 
              : 'Automate Cross-Border Tax, DTAA Relief & Form 10F'}
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 leading-relaxed">
            {language === 'hi'
              ? 'यह 90-सेकंड का वीडियो ट्यूटोरियल देखें, जो दिखाता है कि कैसे भारतीय चार्टर्ड अकाउंटेंट्स, टेक एक्सपोर्टर्स और CFOs हफ्तों के ट्रांसफर प्राइसिंग काम को 3 मिनट में पूरा कर सकते हैं।'
              : 'Watch this 90-second video walkthrough showing how Chartered Accountants, IT service exporters, and corporate CFO desks turn weeks of transfer pricing audits into an instant 3-minute statutory dossier.'}
          </p>

          {/* Voiceover Language Switcher */}
          <div className="flex items-center justify-center gap-2 pt-1">
            <span className="text-xs text-slate-400 flex items-center gap-1">
              <Languages className="w-3.5 h-3.5 text-amber-400" />
              <span>Voiceover Narration:</span>
            </span>
            <div className="inline-flex bg-slate-900 border border-slate-700 rounded-xl p-1 text-xs">
              <button
                type="button"
                onClick={() => handleLanguageToggle('hi')}
                className={`px-3 py-1 rounded-lg font-bold transition cursor-pointer flex items-center gap-1.5 ${
                  language === 'hi' 
                    ? 'bg-amber-500 text-slate-950 shadow-sm' 
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <span>🇮🇳 हिंदी आवाज़ (Hindi Narration)</span>
              </button>
              <button
                type="button"
                onClick={() => handleLanguageToggle('en')}
                className={`px-3 py-1 rounded-lg font-bold transition cursor-pointer flex items-center gap-1.5 ${
                  language === 'en' 
                    ? 'bg-amber-500 text-slate-950 shadow-sm' 
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <span>🇬🇧 English Voiceover</span>
              </button>
            </div>
          </div>
        </div>

        {/* 16:9 Animated Video Player */}
        <div className="relative bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden shadow-2xl">
          <div className="relative aspect-video w-full bg-gradient-to-br from-slate-950 via-slate-900 to-indigo-950 flex flex-col justify-between p-6 sm:p-10 select-none overflow-hidden">
            {/* Ambient Lighting */}
            <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-amber-500/15 via-red-500/10 to-transparent pointer-events-none"></div>

            {/* Scene Header */}
            <div className="relative z-10 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="px-3 py-1 rounded-full text-[11px] font-bold bg-white/10 text-amber-300 border border-white/10 flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse"></span>
                  {language === 'hi' ? `दृश्य ${currentScene.id} / 5` : `SCENE ${currentScene.id} OF 5`}
                </span>
                <span className="text-[11px] font-mono text-slate-400 bg-black/40 px-2.5 py-1 rounded-lg hidden sm:inline-block">
                  {currentScene.tag}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-mono font-bold bg-red-600/30 text-red-300 border border-red-500/30 px-2 py-0.5 rounded">
                  {language === 'hi' ? '🇮🇳 हिंदी ऑडियो' : '🇬🇧 ENGLISH AUDIO'}
                </span>
                <span className="text-[11px] font-mono text-slate-400 bg-black/50 px-2.5 py-1 rounded">
                  IND CROSSTAX AI &bull; 4K UHD
                </span>
              </div>
            </div>

            {/* Scene Center Card */}
            <div className="relative z-10 my-auto py-2">
              <div className="max-w-xl mx-auto text-center space-y-4">
                <h2 className="text-xl sm:text-2xl font-black text-white tracking-tight leading-snug">
                  {currentScene.title}
                </h2>

                <div className="bg-slate-900/90 border border-slate-700/60 rounded-2xl p-5 text-left shadow-2xl backdrop-blur-md">
                  <div className="flex items-center justify-between border-b border-slate-800 pb-2 mb-3">
                    <span className="text-amber-400 font-bold text-xs">{currentScene.tag}</span>
                    <span className={`px-2 py-0.5 rounded text-[10px] font-extrabold border ${currentScene.badgeColor}`}>
                      STATUS: ACTIVE
                    </span>
                  </div>
                  <ul className="space-y-2 text-xs text-slate-300">
                    {currentScene.bullets.map((b, i) => (
                      <li key={i} className="flex items-start gap-2">
                        <span className="text-amber-400 shrink-0 font-bold">&bull;</span>
                        <span>{b}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>

            {/* Subtitles (CC in Hindi / English) */}
            <div className="relative z-10 max-w-3xl mx-auto w-full mb-2">
              <div className="bg-black/90 backdrop-blur-md border border-amber-500/30 px-4 py-2.5 rounded-xl text-center shadow-lg">
                <p className="text-xs sm:text-sm font-semibold text-amber-200 leading-snug">
                  &ldquo;{currentScene.subtitles}&rdquo;
                </p>
              </div>
            </div>

            {/* Player Controls */}
            <div className="relative z-10 bg-slate-900/95 backdrop-blur-md border border-slate-800 rounded-2xl p-3 flex flex-col gap-2">
              {/* Progress bar */}
              <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-gradient-to-r from-amber-500 to-red-600 transition-all duration-100 ease-linear rounded-full"
                  style={{ width: `${progress}%` }}
                ></div>
              </div>

              <div className="flex items-center justify-between text-xs text-slate-300 pt-1">
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={isPlaying ? handlePause : handlePlay}
                    className="px-3.5 py-1.5 bg-red-600 hover:bg-red-700 text-white font-bold rounded-lg transition shadow flex items-center gap-1.5 cursor-pointer"
                  >
                    {isPlaying ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5 fill-white" />}
                    <span>{isPlaying ? 'Pause' : 'Play Video'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={handleRestart}
                    className="p-1.5 rounded-lg border border-slate-700 bg-slate-800 text-slate-300 hover:text-white transition cursor-pointer"
                    title="Restart"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      const next = !voiceEnabled;
                      setVoiceEnabled(next);
                      if (!next) {
                        try {
                          if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
                            window.speechSynthesis.cancel();
                          }
                        } catch {}
                      }
                    }}
                    className="px-2.5 py-1.5 rounded-lg border border-slate-700 bg-slate-800 text-slate-300 hover:text-white text-xs font-bold transition cursor-pointer flex items-center gap-1"
                  >
                    {voiceEnabled ? <Volume2 className="w-3.5 h-3.5 text-amber-400" /> : <VolumeX className="w-3.5 h-3.5 text-slate-500" />}
                    <span>Voiceover: <strong className={voiceEnabled ? 'text-amber-400' : 'text-slate-400'}>{voiceEnabled ? 'ON' : 'OFF'}</strong></span>
                  </button>
                </div>

                {/* Scene Jumpers */}
                <div className="flex items-center gap-1">
                  {scenes.map((s, idx) => (
                    <button
                      key={s.id}
                      type="button"
                      onClick={() => goToScene(idx)}
                      className={`px-2.5 py-1 rounded text-[11px] font-bold cursor-pointer transition ${
                        currentSceneIdx === idx
                          ? 'bg-amber-500 text-slate-950 font-black shadow-sm'
                          : 'bg-slate-800 text-slate-400 hover:bg-slate-700'
                      }`}
                    >
                      {s.id}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Action Panel: YouTube Kit + Offline File + WhatsApp Share */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {/* Card 1: YouTube Publish Kit */}
          <div className="bg-gradient-to-br from-red-950/40 via-slate-900 to-slate-900 border border-red-500/40 rounded-3xl p-5 space-y-3">
            <div className="flex items-center gap-2">
              <span className="p-2 rounded-xl bg-red-600 text-white">
                <Youtube className="w-5 h-5" />
              </span>
              <div>
                <h3 className="font-bold text-white text-sm">YouTube Publish Kit</h3>
                <span className="text-[11px] text-red-300 font-semibold">Titles, Script &amp; Description</span>
              </div>
            </div>
            
            <p className="text-xs text-slate-300 leading-relaxed">
              Copy pre-formatted YouTube titles, timestamps, hashtags, and the complete Hindi voiceover script ready for YouTube Studio.
            </p>

            <button
              type="button"
              onClick={() => setIsYouTubeKitOpen(true)}
              className="w-full py-2.5 px-4 bg-red-600 hover:bg-red-700 text-white font-extrabold text-xs rounded-xl shadow-md transition flex items-center justify-center gap-2 cursor-pointer"
            >
              <Youtube className="w-4 h-4" />
              <span>Open YouTube Kit &amp; Script</span>
            </button>
          </div>

          {/* Card 2: Send Direct Offline Video File */}
          <div className="bg-gradient-to-br from-amber-950/40 via-slate-900 to-slate-900 border border-amber-500/30 rounded-3xl p-5 space-y-3">
            <div className="flex items-center gap-2">
              <span className="p-2 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/30">
                <Download className="w-5 h-5" />
              </span>
              <div>
                <h3 className="font-bold text-white text-sm">Offline HTML Player</h3>
                <span className="text-[11px] text-amber-300 font-semibold">Includes Hindi Narration</span>
              </div>
            </div>
            
            <p className="text-xs text-slate-300 leading-relaxed">
              Download the self-contained HTML file to record your screen in OBS or send it as a WhatsApp attachment to clients.
            </p>

            <button
              type="button"
              onClick={downloadVideoFile}
              className="w-full py-2.5 px-4 bg-amber-500 hover:bg-amber-600 text-slate-950 font-extrabold text-xs rounded-xl shadow-md transition flex items-center justify-center gap-2 cursor-pointer"
            >
              {downloadSuccess ? <Check className="w-4 h-4 text-slate-950" /> : <FileCode className="w-4 h-4" />}
              <span>{downloadSuccess ? 'Downloaded!' : '📥 Download Offline .html'}</span>
            </button>
          </div>

          {/* Card 3: Copy Web Link & WhatsApp Text */}
          <div className="bg-gradient-to-br from-indigo-950/40 via-slate-900 to-slate-900 border border-indigo-500/30 rounded-3xl p-5 space-y-3">
            <div className="flex items-center gap-2">
              <span className="p-2 rounded-xl bg-indigo-500/20 text-indigo-400 border border-indigo-500/30">
                <Share2 className="w-5 h-5" />
              </span>
              <div>
                <h3 className="font-bold text-white text-sm">Share on WhatsApp</h3>
                <span className="text-[11px] text-indigo-300 font-semibold">Direct Pitch with Link</span>
              </div>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">
              Copy the live link or open WhatsApp with a ready-made Hindi introductory pitch message for clients.
            </p>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => copyToClipboard(videoShareUrl)}
                className="flex-1 py-2.5 px-3 bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs rounded-xl border border-slate-700 transition cursor-pointer flex items-center justify-center gap-1.5"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'Copied' : 'Copy'}</span>
              </button>

              <a
                href={`https://api.whatsapp.com/send?text=${whatsappMessage}`}
                target="_blank"
                rel="noopener noreferrer"
                className="flex-1 py-2.5 px-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl transition shadow flex items-center justify-center gap-1.5"
              >
                <Smartphone className="w-3.5 h-3.5" />
                <span>WhatsApp</span>
              </a>
            </div>
          </div>
        </div>

        {/* Commercials & Scope for CA Offices */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2">
          <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-2">
            <span className="text-amber-400 font-bold text-xs uppercase tracking-wider block">Service 1</span>
            <h4 className="font-bold text-white text-sm">Form 10F &amp; No-PE Packs</h4>
            <p className="text-xs text-slate-400 leading-relaxed">
              Statutory declarations required by foreign clients to eliminate 20% withholding tax on software exports.
            </p>
            <div className="text-xs font-bold text-amber-300 pt-1">Fee: ₹5,000 – ₹15,000 / filing</div>
          </div>

          <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-2">
            <span className="text-indigo-400 font-bold text-xs uppercase tracking-wider block">Service 2</span>
            <h4 className="font-bold text-white text-sm">Transfer Pricing Safe Harbour</h4>
            <p className="text-xs text-slate-400 leading-relaxed">
              OECD &amp; CBDT Chapter X arm's length profit markups (TNMM, Safe Harbour Rule 10TD).
            </p>
            <div className="text-xs font-bold text-indigo-300 pt-1">Fee: ₹25,000 – ₹60,000 / study</div>
          </div>

          <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-2">
            <span className="text-emerald-400 font-bold text-xs uppercase tracking-wider block">Service 3</span>
            <h4 className="font-bold text-white text-sm">Monthly CFO &amp; Tax Retainer</h4>
            <p className="text-xs text-slate-400 leading-relaxed">
              Ongoing treaty verification for IT agencies, SaaS startups, and multinational contracts.
            </p>
            <div className="text-xs font-bold text-emerald-300 pt-1">Fee: ₹20,000 – ₹50,000 / mo</div>
          </div>
        </div>
      </main>

      {/* YouTube Creator & Publish Studio Modal */}
      {isYouTubeKitOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-slate-900 rounded-3xl max-w-3xl w-full p-6 shadow-2xl border border-slate-800 max-h-[90vh] flex flex-col text-slate-100">
            {/* Modal Header */}
            <div className="flex items-center justify-between pb-4 border-b border-slate-800">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-red-600 text-white flex items-center justify-center shadow-md">
                  <Youtube className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-extrabold text-white text-base">YouTube Publishing Kit &amp; Hindi Script</h3>
                  <p className="text-xs text-slate-400">Everything you need to record, narrate, and publish on YouTube</p>
                </div>
              </div>
              <button
                onClick={() => setIsYouTubeKitOpen(false)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Body */}
            <div className="overflow-y-auto py-4 space-y-5 pr-1 text-xs">
              {/* Section 1: Click-Worthy YouTube Titles */}
              <div className="space-y-2">
                <span className="font-bold text-amber-400 uppercase tracking-wider text-[11px] block">
                  1. High CTR YouTube Titles (Choose One):
                </span>
                <div className="space-y-2">
                  {[
                    "विदेशी इनवॉइस पर 20% Tax कैसे बचाएं? DTAA Relief & Form 10F Complete Guide (हिंदी) | IND CROSSTAX AI",
                    "How Indian IT Exporters & CAs Save 20% WHT on US/UK Invoices | IND CROSSTAX AI Demo (हिंदी)",
                    "Transfer Pricing Safe Harbour Rule 10TD & Form 10F Explained in Hindi | Cross-Border Tax Engine"
                  ].map((titleOption, idx) => (
                    <div key={idx} className="flex items-center justify-between p-2.5 bg-slate-950 rounded-xl border border-slate-800 gap-2">
                      <span className="text-white font-medium select-all leading-snug">{titleOption}</span>
                      <button
                        onClick={() => copyKitText(titleOption, `title-${idx}`)}
                        className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 text-[11px] font-bold transition shrink-0 flex items-center gap-1 cursor-pointer"
                      >
                        {copiedKitSection === `title-${idx}` ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                        <span>{copiedKitSection === `title-${idx}` ? 'Copied' : 'Copy'}</span>
                      </button>
                    </div>
                  ))}
                </div>
              </div>

              {/* Section 2: Ready-to-Paste YouTube Description */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-amber-400 uppercase tracking-wider text-[11px]">
                    2. YouTube Description with Timestamps &amp; Hashtags:
                  </span>
                  <button
                    onClick={() => copyKitText(youtubeDescriptionText, 'description')}
                    className="px-2.5 py-1 rounded bg-red-600 hover:bg-red-700 text-white text-[11px] font-bold transition flex items-center gap-1 cursor-pointer"
                  >
                    {copiedKitSection === 'description' ? <Check className="w-3.5 h-3.5 text-white" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedKitSection === 'description' ? 'Copied Description!' : 'Copy Description'}</span>
                  </button>
                </div>
                <textarea
                  readOnly
                  rows={8}
                  value={youtubeDescriptionText}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 font-mono text-[11px] text-slate-300 focus:outline-none select-all"
                />
              </div>

              {/* Section 3: Word-by-Word Hindi Voiceover Teleprompter Script */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-amber-400 uppercase tracking-wider text-[11px]">
                    3. Hindi Voiceover Script (Teleprompter Ready):
                  </span>
                  <button
                    onClick={() => copyKitText(youtubeScriptFullHindi, 'script')}
                    className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 text-[11px] font-bold transition flex items-center gap-1 cursor-pointer"
                  >
                    {copiedKitSection === 'script' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedKitSection === 'script' ? 'Copied Script!' : 'Copy Full Script'}</span>
                  </button>
                </div>
                <div className="bg-slate-950 border border-slate-800 rounded-xl p-4 space-y-3 leading-relaxed text-slate-200 text-xs">
                  <div className="p-2.5 rounded-lg bg-slate-900 border border-slate-800">
                    <strong className="text-amber-400 block mb-1">दृश्य 1: समस्या (0:00 - 0:45)</strong>
                    नमस्ते दोस्तों! क्या आपके भारतीय IT क्लाइंट्स, SaaS एक्सपोर्टर्स और फ्रीलांसर्स विदेशी इनवॉइस पर 15 से 20 प्रतिशत टैक्स टीडीएस में गंवा रहे हैं? हर साल करोड़ों रुपये गैर-जरूरी डबल टैक्सेशन और ट्रांसफर प्राइसिंग के विवादों में अटक जाते हैं। समय आ गया है इस टैक्स लीकेज को रोकने का!
                  </div>

                  <div className="p-2.5 rounded-lg bg-slate-900 border border-slate-800">
                    <strong className="text-amber-400 block mb-1">दृश्य 2: समाधान (0:45 - 1:35)</strong>
                    पेश है IND CROSSTAX AI — भारतीय चार्टर्ड अकाउंटेंट्स, कॉर्पोरेट फाइनेंस टीम्स और IT एक्सपोर्टर्स के लिए बनाया गया नेक्स्ट-जेनरेशन टैक्स ऑटोमेशन प्लेटफॉर्म। जो टैक्स रिसर्च हफ्तों का समय लेती थी, अब वो सिर्फ 3 मिनट में पूरी ऑडिट-रेडी फाइल के साथ तैयार हो जाती है!
                  </div>

                  <div className="p-2.5 rounded-lg bg-slate-900 border border-slate-800">
                    <strong className="text-amber-400 block mb-1">दृश्य 3: लाइव ट्यूटोरियल (1:35 - 2:45)</strong>
                    इस प्लेटफॉर्म को इस्तेमाल करना बहुत आसान है। स्टेप 1: अपने कॉन्ट्रैक्ट और देश की डिटेल्स दर्ज करें। स्टेप 2: हमारा AI इंजन DTAA आर्टिकल्स, परमानेंट एस्टेब्लिशमेंट रिस्क, FTS फीस और आर्म्स लेंथ मार्जिन की सटीक जांच करता है। और स्टेप 3: सिंगल क्लिक में सरकारी Form 10F और No-PE सर्टिफिकेट वर्ड फॉर्मेट में डाउनलोड करें।
                  </div>

                  <div className="p-2.5 rounded-lg bg-slate-900 border border-slate-800">
                    <strong className="text-amber-400 block mb-1">दृश्य 4: कमाई का मौका (2:45 - 3:45)</strong>
                    सीए फर्म्स और टैक्स कंसल्टेंट्स के लिए यह कमाई का बेहतरीन जरिया है। बिना किसी इंटरनेशनल टैक्स एक्सपर्ट को हायर किए, अपने क्लाइंट्स को प्रीमियम क्रॉस-बॉर्डर एडवाइजरी दें और हर असाइनमेंट पर 25 हजार से 1 लाख रुपये तक की प्रोफेशनल फीस अर्जित करें। साथ ही रियल-टाइम RBI और इंटरबैंक करेंसी रेट्स पर तुरंत कैलकुलेशन पाएं।
                  </div>

                  <div className="p-2.5 rounded-lg bg-slate-900 border border-slate-800">
                    <strong className="text-amber-400 block mb-1">दृश्य 5: आउट्रो (3:45 - 4:40)</strong>
                    डबल टैक्सेशन में अपने पैसे गंवाना बंद करें। आज ही IND CROSSTAX AI का उपयोग करें। लिंक नीचे डिस्क्रिप्शन बॉक्स में दिया गया है — ind-crosstax-ai.vercel.app। वीडियो पसंद आई हो तो लाइक करें, चैनल को सब्सक्राइब करें और अपने सभी सीए व फाउंडर दोस्तों के साथ शेयर करें। धन्यवाद!
                  </div>
                </div>
              </div>

              {/* Section 4: Screen Recording Tips for YouTube (1080p 60FPS) */}
              <div className="p-3.5 bg-gradient-to-r from-slate-950 to-slate-900 rounded-xl border border-slate-800 space-y-1.5">
                <span className="font-bold text-white flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                  <span>How to Record Screen for YouTube (1080p 60FPS):</span>
                </span>
                <ul className="list-disc list-inside space-y-1 text-slate-400 text-[11px]">
                  <li>Press <kbd className="bg-slate-800 px-1 py-0.5 rounded text-amber-300">F11</kbd> on Windows or <kbd className="bg-slate-800 px-1 py-0.5 rounded text-amber-300">Ctrl+Cmd+F</kbd> on Mac to go Fullscreen.</li>
                  <li>Use OBS Studio, Loom, or Windows Xbox Game Bar (<kbd className="bg-slate-800 px-1 py-0.5 rounded text-slate-200">Win+Alt+R</kbd>) to capture at 1080p 60fps.</li>
                  <li>Click <strong>&ldquo;Play Video&rdquo;</strong> with <strong>&ldquo;🇮🇳 हिंदी आवाज़&rdquo;</strong> enabled, or read the script above with your external microphone!</li>
                </ul>
              </div>
            </div>

            {/* Modal Footer */}
            <div className="pt-3 border-t border-slate-800 flex justify-between items-center">
              <span className="text-[11px] text-slate-500">Live URL: ind-crosstax-ai.vercel.app</span>
              <button
                type="button"
                onClick={() => setIsYouTubeKitOpen(false)}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white font-bold rounded-xl text-xs transition cursor-pointer"
              >
                Close Kit
              </button>
            </div>
          </div>
        </div>
      )}

      <footer className="border-t border-slate-800 py-6 text-center text-xs text-slate-500">
        <p>IND CROSSTAX AI &bull; Dedicated Video Presentation Portal &bull; Free Live Access at ind-crosstax-ai.vercel.app</p>
      </footer>
    </div>
  );
};
